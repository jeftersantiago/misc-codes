ls -la | grep rwx

