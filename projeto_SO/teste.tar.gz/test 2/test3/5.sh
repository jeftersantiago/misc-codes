#!/usr/bin/python
print('Oi')
