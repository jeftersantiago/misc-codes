for file in *
do
	echo "$file"
done
