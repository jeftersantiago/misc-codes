#!/bin/bash
echo $1

